create definer = root@localhost trigger before_student_insert_or_update
    before insert
    on student
    for each row
BEGIN
  IF NEW.sex NOT IN ('男', '女') THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = '性别只能是男或女';
  END IF;
END;

