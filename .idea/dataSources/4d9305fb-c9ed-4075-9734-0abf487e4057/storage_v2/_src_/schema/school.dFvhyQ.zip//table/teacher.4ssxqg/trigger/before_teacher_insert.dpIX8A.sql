create definer = root@localhost trigger before_teacher_insert
    before insert
    on teacher
    for each row
BEGIN
  IF NEW.sex NOT IN ('男', '女') THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = '性别只能是男或女';
  END IF;
  IF NEW.sex = '男' AND NEW.salary <= 6500 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = '男性教师工资必须超过6500元';
  END IF;
END;

