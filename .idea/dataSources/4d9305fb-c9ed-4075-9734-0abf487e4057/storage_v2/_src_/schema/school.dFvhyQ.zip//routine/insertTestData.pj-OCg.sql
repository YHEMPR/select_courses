create
    definer = root@localhost procedure insertTestData()
BEGIN
  DECLARE current_count INT;
  SELECT MAX(id) INTO current_count FROM test_data;
  IF current_count IS NULL THEN
    SET current_count = 0;
  END IF;
  WHILE current_count < 10000000 DO
    INSERT INTO test_data (data_field, indexed_field) VALUES (CONCAT('Data ', current_count), current_count);
    SET current_count = current_count + 1;
  END WHILE;
END;

