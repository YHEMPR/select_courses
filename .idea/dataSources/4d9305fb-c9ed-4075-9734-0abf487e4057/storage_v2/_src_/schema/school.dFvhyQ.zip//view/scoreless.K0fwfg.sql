create definer = root@localhost view scoreless as
select `s`.`student_id`   AS `student_id`,
       `s`.`name`         AS `name`,
       `s`.`sex`          AS `sex`,
       `s`.`mobile_phone` AS `mobile_phone`,
       `c`.`course_name`  AS `course_name`,
       `cs`.`score`       AS `score`
from ((`school`.`student` `s` join `school`.`course_selection` `cs`
       on ((`s`.`student_id` = `cs`.`student_id`))) join `school`.`course` `c`
      on ((`cs`.`course_id` = `c`.`course_id`)))
where ((`cs`.`score` < 60) and (`c`.`course_id` = `cs`.`course_id`) and (`s`.`dept_id` = '01'));

-- comment on column scoreless.student_id not supported: 学号

-- comment on column scoreless.student_name not supported: 姓名

-- comment on column scoreless.sex not supported: 性别

-- comment on column scoreless.phone_number not supported: 手机号码

-- comment on column scoreless.selectedcourse not supported: 课名

-- comment on column scoreless.score not supported: 成绩

