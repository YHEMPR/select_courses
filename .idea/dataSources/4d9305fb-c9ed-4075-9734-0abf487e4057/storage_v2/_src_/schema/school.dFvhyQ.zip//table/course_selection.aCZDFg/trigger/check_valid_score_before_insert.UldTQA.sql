create definer = root@localhost trigger check_valid_score_before_insert
    before insert
    on course_selection
    for each row
BEGIN
    IF NEW.score IS NOT NULL AND (NEW.score < 0 OR NEW.score > 100) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '成绩必须在0到100分之间';
    END IF;
END;

